package com.pages;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import com.Parent.P_Base;

public class contactpage extends P_Base {
	By contactus = By.xpath("//button[@data-qa='login-button']");
	By getintouchlabel =By.xpath("//h2[text()='Get In Touch']");
	By name=By.xpath("//input[@placeholder='Name']");
	By email = By.xpath("//input[@name='email']");
	By subject = By.xpath("//input[@name='subject']");
	By message= By.xpath("//textarea[@id='message']");
	By uploadfile= By.xpath("//input[@type='file']");
	By submitbtn = By.xpath("//input[@type='submit']");
	By sucesslabel = By.xpath("//div[text()='Success! Your details have been submitted successfully.']");
	By vsuccess = By.xpath("//div[@class='status alert alert-success']");
	
	
	
	
	
	
	
	public void TC6_clickoncontact() {

		driver.findElement(contactus).click();
	}
	public boolean verifygetintouch() {
		return driver.findElement(getintouchlabel).isDisplayed();
	}
	public void fillTheDtails() {

		driver.findElement(name).sendKeys(prop.getProperty("contactname"));

		driver.findElement(email).sendKeys(prop.getProperty("contactmail"));
	

		driver.findElement(subject).sendKeys("csubject");

		driver.findElement(message).sendKeys("cmessage");
		Actions act = new Actions(driver);
		act.scrollByAmount(0, 500).perform();
		
	}
	
	public void UploadFile() {

		driver.findElement(uploadfile).sendKeys(prop.getProperty("cfile"));
		
		driver.findElement(submitbtn).click();
		
		Alert alrt = driver.switchTo().alert();
        alrt.accept();	
        
		WebElement home = driver.findElement(By.xpath("//span[normalize-space()='Home']"));
		home.click();           
		
	}
	
	public boolean verifysuccess() {
//		WebElement vs = driver.findElement(By.xpath("//div[@class='status alert alert-success']"));
//		return vs.isDisplayed();
		return driver.findElement(vsuccess).isDisplayed();
		
	}	
public void scrollingdown() {
		
		Actions act =new Actions(driver);
		
		WebElement menu=driver.findElement(submitbtn);
		act.scrollToElement(menu).perform();
	}
	

}
