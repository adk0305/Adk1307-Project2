package com.pages;

import org.openqa.selenium.By;

import com.Parent.P_Base;

public class CatagoryPage extends P_Base {
	By presentcatgry = By.xpath("//h2[normalize-space()='Category']");
	By Womens = By.xpath("//a[normalize-space()='Women']");
	By Dress = By.xpath("//div[@id='Women']//a[contains(text(),'Dress')]");
	By TopPrdcts = By.xpath("//h2[normalize-space()='Women - Dress Products']");
	By Men = By.xpath("//a[normalize-space()='Men']");
	By shirts = By.xpath("//a[normalize-space()='Tshirts']");
	public boolean TC18_Catagory() {
		return driver.findElement(presentcatgry).isDisplayed();
	}
	public void click_on_Womenscatagory() {
		driver.findElement(Womens).click();
		
	}
	public void click_on_Dress() {
		driver.findElement(Dress).click();
		
	}
	public boolean Verify_Top_Products() {
		return driver.findElement(TopPrdcts).isDisplayed();
		
	}
	public void click_on_Men() {
		driver.findElement(Men).click();
	}
	public void click_on_shirts() {
		driver.findElement(shirts).click();
	}

}
