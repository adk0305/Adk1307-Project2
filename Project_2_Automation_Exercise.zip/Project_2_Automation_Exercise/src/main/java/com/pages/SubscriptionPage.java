package com.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import com.Parent.P_Base;

public class SubscriptionPage extends P_Base {
	By Vsubscrptiontext = By.xpath("//h2[normalize-space()='Subscription']");
	By Email = By.id("susbscribe_email");
	By clickarrow = By.xpath("//i[@class='fa fa-arrow-circle-o-right']");
	By Verifysuccessfyllysbscrbd = By.xpath("//h2[normalize-space()='You have been successfully subscribed!']");
	
	
	
	public void TC10_ScrollToFooter() {		
		Actions act = new Actions(driver);
		act.scrollByAmount(0, 10000).perform();
	}
	
public boolean VerifySubscriptionText() {
	return driver.findElement(Vsubscrptiontext).isDisplayed();
}

public void EnterEmail() {

	driver.findElement(Email).sendKeys(prop.getProperty("subEmail"));
	driver.findElement(clickarrow).click();
	
}
public boolean VerifySuccessfullySbscribed() {
return driver.findElement(Verifysuccessfyllysbscrbd).isDisplayed();
	
}
}
