package com.pages;

import java.sql.Driver;
import java.time.Duration;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import com.Parent.P_Base;
public class placeorderPage extends P_Base {
	
//	By homep = By.xpath("//a[normalize-space()='Home']");
//	By clickonproduct = By.xpath("//a[@href='/products']"); 
	By Checkout = By.xpath("//a[normalize-space()='Proceed To Checkout']");
	By name = By.xpath("//input[@placeholder='Name']");
	 By email = By.xpath("//input[@data-qa='signup-email']");
		By sb1 = By.xpath("//button[@data-qa='signup-button']");
		By verifyaddressdetails = By.xpath("//h2[normalize-space()='Address Details']");
	By ReviewOrder = By.xpath("//h2[normalize-space()='Review Your Order']");
	By Text = By.xpath("//textarea[@name='message']");	
	By placeorder = By.xpath("//a[normalize-space()='Place Order']");	
	By RegisterorLogin = By.xpath("//u[normalize-space()='Register / Login']");
	By deletebtn = By.xpath("//a[normalize-space()='Delete Account']");
	By Vdltbtn = By.xpath("//b[normalize-space()='Account Deleted!']");
	By cntnue = By.xpath("//a[normalize-space()='Continue']");
	By usernameintop = By.xpath("//b[normalize-space()='Deepu']");
	public void ProceedtoCheckout() {
		driver.findElement(Checkout).click();
		
	}
	public void ClickonRegister_login() {
		driver.findElement(RegisterorLogin).click();
	}
	
	public void TC14_CAN() {
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		driver.findElement(name).sendKeys(prop.getProperty("CAName"));	
	driver.findElement(email).sendKeys(prop.getProperty("CAMail"));
		driver.findElement(sb1).click();
	}
	public void alerthndl() {
		Alert alrt = driver.switchTo().alert();
        alrt.dismiss();	
		
	}
	public void VerifyAddressandRevieworder() {
		driver.findElement(verifyaddressdetails).isDisplayed();
	driver.findElement(ReviewOrder).isDisplayed();
	
	}
	public void commentText() {
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		Actions act = new Actions(driver);
		act.scrollByAmount(0, 500).perform();
		driver.findElement(Text).sendKeys(prop.getProperty("commentText"));	
	}
	public void PlaceOrder() {
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		driver.findElement(placeorder).click();
		
	}
	public void clickondeletebtn() {
		driver.findElement(deletebtn).click();
		
	}
	public boolean verifyaccountdltdAndcontinue() {
		return driver.findElement(Vdltbtn).isDisplayed();

	}
	
	public void clickcontinue() {
		
		driver.findElement(cntnue).click();
	}
	
	public boolean TC16_VusernameinTop() {
		return driver.findElement(usernameintop).isDisplayed();
		
	}
	
		
	}	



