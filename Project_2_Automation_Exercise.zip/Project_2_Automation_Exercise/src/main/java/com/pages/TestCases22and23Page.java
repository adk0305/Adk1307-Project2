package com.pages;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.interactions.Actions;

import com.Parent.P_Base;

public class TestCases22and23Page extends P_Base {

	By recommended = By.xpath("//h2[normalize-space()='recommended items']");
	By item = By.xpath("//div[@class='item active']//div[2]//div[1]//div[1]//div[1]//a[1]");
	By cart = By.xpath("//u[normalize-space()='View Cart']");
	By delacc = By.xpath("//a[text()=' Delete Account']");
	By delacclbl = By.xpath("//b[text()='Account Deleted!']");	
	
	public void TC22_scrolldown() {
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));

		Actions act = new Actions(driver);
		act.scrollByAmount(0, 5000).perform();	
		
	}
	public boolean RItems() {
		return driver.findElement(recommended).isDisplayed();
	}
	
	public void shirt() {
		driver.findElement(item).click();
		
	}
	public void viewcart() {
		driver.findElement(cart).click();
	}
	
	public void deleteacc() {
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));
		driver.findElement(delacc).click();
	}
	public boolean verify_delacc() {
		return driver.findElement(delacclbl).isDisplayed();
	}
	
}
