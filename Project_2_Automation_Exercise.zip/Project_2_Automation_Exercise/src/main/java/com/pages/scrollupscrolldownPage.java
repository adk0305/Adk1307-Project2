package com.pages;

import java.time.Duration; 

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.interactions.Actions;

import com.Parent.P_Base;
//import com.automation.pages.ProductPage;


public class scrollupscrolldownPage extends P_Base {
	By scrollup= By.xpath("//a[@id='scrollUp']");
	By verify_fulllabel= By.xpath("//h2[text()='Full-Fledged practice website for Automation Engineers']");
	 By addtop=By.xpath("//p[text()='Summer White Top']//ancestor::div[@class='product-overlay']//descendant::a[text()='Add to cart']");
	 By selecttop= By.xpath("//p[text()='Stylish Dress']");
	 By payment=By.xpath("//h2[text()='Payment']");
		By nameofcard=By.xpath("//input[@name='name_on_card']");
		By cardno= By.xpath("//input[@name='card_number']");
		By cvc=By.xpath("//input[@name='cvc']");
		By expirationmm = By.xpath("//input[@name='expiry_month']");
		By expiryyear= By.xpath("//input[@name='expiry_year']");
		By confirmbtn=By.xpath("//button[text()='Pay and Confirm Order']");
		By orderplaced=By.xpath("//p[text()='Congratulations! Your order has been confirmed!']");
		By downloadinvoice= By.xpath("//a[text()='Download Invoice']");
		By continuebtn= By.xpath("//a[text()='Continue']");
		By verifyaddress= By.xpath("//h3[text()='Your delivery address']");
		By verifyrevieworder= By.xpath("//h2[text()='Review Your Order']");
		By msg = By.xpath("//textarea[@name='message']");
		By placeorder=By.xpath("//a[text()='Place Order']");

	public void TC26_ScrolldowntoBottom() {
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));

		Actions act = new Actions(driver);
		act.scrollByAmount(0, 10000).perform();		
	}
	
	
public void click_Scrollup_arrowbtn() {
		
		JavascriptExecutor js=(JavascriptExecutor) driver;
		js.executeScript("arguments[0].click()", driver.findElement(scrollup));
	}
public void scrollup() {
	driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));

    driver.findElement(scrollup).click();

}
	public boolean verify_fullWebsite() {
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));

		return driver.findElement(verify_fulllabel).isDisplayed();
		
	}
	public ProductPage addtop() {
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));
		JavascriptExecutor js=(JavascriptExecutor) driver;
		//js.executeScript("arguments[0].scrollIntoView()",addtop);
		js.executeScript("arguments[0].click()",driver.findElement(addtop) );
		return new ProductPage();

	}
	
	
	public boolean verifyAddreesinCHeckout() {
		
		return driver.findElement(verifyaddress).isDisplayed();
}
public boolean verifyReviewOrderinCHeckout() {
	
	return driver.findElement(verifyrevieworder).isDisplayed();
}
public void entermsg() {
	
	 driver.findElement(msg).sendKeys("Test");
}
public paymentPage clickplaceorder() {
	
	driver.findElement(placeorder).click();
	return new paymentPage();


}
	

	
		
	}



