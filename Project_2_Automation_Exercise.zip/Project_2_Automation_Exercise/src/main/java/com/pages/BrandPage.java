package com.pages;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.interactions.Actions;

import com.Parent.P_Base;

public class BrandPage extends P_Base{
	
	By brand = By.xpath("//h2[normalize-space()='Brands']");
	By brandName = By.xpath("//a[@href='/brand_products/Madame']");
	By brandproduct = By.xpath("//h2[normalize-space()='Brand - Madame Products']");
	By anotherbrand = By.xpath("//a[@href='/brand_products/H&M']");
	By brandproduct1 = By.xpath("//h2[normalize-space()='Brand - H&M Products']");
	
	
	
	public boolean TC19_Brand_Present() {
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		return driver.findElement(brand).isDisplayed(); 
				
	}
	public void click_on_brand() {
	//	driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
	driver.findElement(brandName).click();	
	Actions act = new Actions(driver);
	act.scrollByAmount(0, 500).perform();
	
	}
	
    public boolean Verify_brand_product() {
	return driver.findElement(brandproduct).isDisplayed();
}

    public void click_another_brand() {
		driver.findElement(anotherbrand).click();
	}
    public boolean Verify_another_brand() {
    //	driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		return driver.findElement(brandproduct1).isDisplayed();
	}
}
