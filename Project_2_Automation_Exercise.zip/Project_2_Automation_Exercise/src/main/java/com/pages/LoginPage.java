package com.pages;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.Parent.P_Base;


public class LoginPage extends P_Base{

	By login = By.xpath("//b[normalize-space()='deepu']");
	By invalid = By.xpath("//p[normalize-space()='Your email or password is incorrect!']");
	By logemail = By.xpath("//input[@data-qa='login-email']");
	By logpassword = By.xpath("//input[@data-qa='login-password']");
	By loginbtn = By.xpath("//button[@data-qa='login-button']");
	By invalidmail = By.xpath("//input[@data-qa='login-email']");
	By invldpassword = By.xpath("/input[@placeholder='Password']");
	By clickloginbtn = By.xpath("//button[@data-qa='login-button']");
	By logout = By.xpath("//a[normalize-space()='Logout']");
	By newsignup = By.xpath("//h2[normalize-space()='New User Signup!']");
	By Existingmail = By.xpath("//input[@data-qa='login-email']");
	By Exostingpassword= By.xpath("//input[@placeholder='Password']");
	By clicklogin = By.xpath("//button[@data-qa='login-button']");
	public boolean verifyloggedinuser() {	
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));

	    return driver.findElement(login).isDisplayed();
	}
	public boolean mailandpasswrdisincorrect() {
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		
		return driver.findElement(invalid).isDisplayed();
		
	}
	public void TC2_LoginDetails() {		
	
			driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
			driver.findElement(By.xpath("//a[text()=' Signup / Login']")).click();
			

			driver.findElement(logemail).sendKeys(prop.getProperty("Loginmail"));	
			driver.findElement(logpassword).sendKeys(prop.getProperty("Loginpassword"));
			
			driver.findElement(loginbtn).click();
}
	public void TC3_invaliddetails() {
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		driver.findElement(By.xpath("//a[text()=' Signup / Login']")).click();
	
		driver.findElement(invalidmail).sendKeys(prop.getProperty("invalidmail"));	
		driver.findElement(invldpassword).sendKeys(prop.getProperty("invldpassword"));
	
		
		driver.findElement(clickloginbtn).click();
	}
	
	public void TC4_Logout() {
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));
		driver.findElement(logout).click();	
		
		
	}
	public boolean TC5_VerifyNewSignup() {
		
		return driver.findElement(newsignup).isDisplayed();
			
	}
	public void existingmailid() {
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		driver.findElement(By.xpath("//a[text()=' Signup / Login']")).click();
		

		driver.findElement(Existingmail).sendKeys(prop.getProperty("Loginmail"));
		driver.findElement(Exostingpassword).sendKeys(prop.getProperty("Loginpassword"));
	
		driver.findElement(clicklogin).click();
	}
	public boolean VEmailalrdyexist() {
		WebElement exist=driver.findElement(By.xpath("//p[normalize-space()='Email Address already exist!']"));
		return exist.isDisplayed();
		
	}
		
	}
