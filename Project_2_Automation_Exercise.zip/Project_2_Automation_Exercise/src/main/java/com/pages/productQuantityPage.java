package com.pages;

import java.time.Duration;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import com.Parent.P_Base;

public class productQuantityPage extends P_Base {
	By clickonproduct = By.xpath("//a[@href='/products']"); 
	By viewprdct = By.xpath("//div[3]//div[1]//div[2]//ul[1]//li[1]//a[1]");
	By increasequantity = By.name("quantity");
	By addtocart = By.xpath("//button[normalize-space()='Add to cart']");
	By ViewCart = By.xpath("//u[normalize-space()='View Cart']");
	By Verifyqntity = By.xpath("//td[@class='quantity']");
	
	public void TC9_Products() {
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
	
		driver.findElement(clickonproduct).click();
		
	//	Alert alrt = driver.switchTo().alert();
  //      alrt.dismiss();	
		Actions act = new Actions(driver);
		act.scrollByAmount(0, 500).perform();		
	}	
	
	
	public void TC13_ClickViewProduct() {
		driver.findElement(viewprdct).click();
		
	}
	public void increasequantity() {
		Actions act = new Actions(driver);
		WebElement qty = driver.findElement(By.name("quantity"));
		qty.click();		
		act.moveToElement(qty).doubleClick(qty).sendKeys(qty, Keys.CONTROL,"a",Keys.BACK_SPACE)
		.build().perform();
		driver.findElement(increasequantity).sendKeys(prop.getProperty("Quantity"));
	}
	public void clickAddtocart() {
		driver.findElement(addtocart).click();
	}
	public void viewcart() {
		driver.findElement(ViewCart).click();
		
	}
	public boolean VerifyQuantity() {
		return driver.findElement(Verifyqntity).isDisplayed();
	}
	
	
	

}
