package com.pages;

import java.sql.Driver;
import java.time.Duration;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

import com.Parent.P_Base;

public class SignupPage extends P_Base {
	By acinfo = By.xpath("//b[normalize-space()='Enter Account Information']");
	By name = By.xpath("//input[@placeholder='Name']");
	By signup_login_btn = By.xpath("//a[text()=' Signup / Login']");
    By email = By.xpath("//input[@data-qa='signup-email']");
	By sb = By.xpath("//button[@data-qa='signup-button']");
	By acc = By.xpath("//b[normalize-space()='Account Created!']");
	By login = By.xpath("//b[normalize-space()='deepu']");
	By title = By.xpath("//input[@id='id_gender2']");
	By pword = By.xpath("//input[@id='password']");
	By days = By.xpath("//select[@id='days']");
	By month = By.xpath("//select[@id='months']");
	By yr = By.xpath("//select[@id='years']");
	By newsltr = By.xpath("//label[text()='Sign up for our newsletter!']");
	By checkboxoffer = By.xpath("//input[@id='optin']");
	By fname=By.xpath("//p[@class='required form-group']//child::input[@id='first_name']");
	By lname=By.xpath("//p[@class='required form-group']//child::input[@id='last_name']");
	By cmpny=By.xpath("//p[@class='form-group']//child::input[@id='company']");
	By adrs1=By.xpath("//p[@class='required form-group']//child::input[@id='address1']");
	By adrs2=By.xpath("//p[@class='required form-group']//child::input[@id='address2']");
	By country=By.xpath("//select[@id='country']");
	By state=By.xpath("//p[@class='required form-group']//child::input[@id='state']");
	By city=By.xpath("//p[@class='required form-group']//child::input[@id='city']");
	By zcode=By.xpath("//p[@class='required form-group']//child::input[@id='zipcode']");
	By mobilenumber=By.xpath("//p[@class='required form-group']//child::input[@id='mobile_number']");
	By createaccount = By.xpath("//button[@data-qa='create-account']");
	By createdaccount = By.xpath("//b[text()='Account Created!']");
	By continuebutton =By.xpath("//a[text()='Continue']");
    By deleteacc = By.xpath("//header/div[1]/div[1]/div[1]/div[2]/div[1]/ul[1]/li[5]/a[1]");	
	
	public boolean verify_Signup_login_Btn_Present() {

	return driver.findElement(signup_login_btn).isDisplayed();
}
	
	public void TC1_signup_login() {
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		driver.findElement(By.xpath("//a[text()=' Signup / Login']")).click();
		
	}
	
	public void CA() {
		driver.findElement(name).sendKeys(prop.getProperty("Signupname"));	
	driver.findElement(email).sendKeys(prop.getProperty("Signupemail"));
		driver.findElement(sb).click();
	}
	public boolean verifysignupdetails() {
		
		return driver.findElement(acinfo).isDisplayed();
	}  
		public boolean verifyacc_created() {	    

		return driver.findElement(acc).isDisplayed();
	}

		public boolean verifyloggedinuser() {	    
		    return driver.findElement(login).isDisplayed();    
		}

	
	public void fillsignupdetails() {
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));
		driver.findElement(title).click();
		driver.findElement(pword).sendKeys(prop.getProperty("signinpassword"));
		driver.findElement(days).sendKeys(prop.getProperty("bdate"));
		driver.findElement(month).sendKeys(prop.getProperty("bmonth"));
		driver.findElement(yr).sendKeys(prop.getProperty("byear"));
		Actions act = new Actions(driver);
		act.scrollByAmount(0, 500).perform();	
		driver.findElement(newsltr).click();
		driver.findElement(checkboxoffer).click();		
	}
public void filladdressinfo() {
driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
driver.findElement(fname).sendKeys(prop.getProperty("firstname"));
driver.findElement(lname).sendKeys(prop.getProperty("lastname"));
driver.findElement(cmpny).sendKeys(prop.getProperty("company"));
driver.findElement(adrs1).sendKeys(prop.getProperty("address1"));
driver.findElement(adrs2).sendKeys(prop.getProperty("address2"));
driver.findElement(country).sendKeys(prop.getProperty("country"));
driver.findElement(state).sendKeys(prop.getProperty("state"));
driver.findElement(city).sendKeys(prop.getProperty("city"));
driver.findElement(zcode).sendKeys(prop.getProperty("zopcode"));
driver.findElement(mobilenumber).sendKeys(prop.getProperty("Mnumber"));
	}
public void click_create_account() {

driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(150));
		
driver.findElement(createaccount).click();
driver.findElement(continuebutton).click();
driver.findElement(deleteacc).click();

	}

}