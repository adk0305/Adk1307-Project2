package com.TC;

import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.pages.SubscriptionPage;

public class SubscriptionPageTest {

	SubscriptionPage sp;
	@BeforeMethod
	public void browserSetup() {
		sp = new SubscriptionPage();
		sp.initialization();	
	}
	
	
	@Test
	public void TC10_Subscriptionpage() {
		sp.TC10_ScrollToFooter();
		Assert.assertTrue(sp.VerifySubscriptionText());
		sp.EnterEmail();
		Assert.assertTrue(sp.VerifySuccessfullySbscribed());
	}
}
