package com.TC;

import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.pages.CatagoryPage;

public class CatagoryPageTest {
	CatagoryPage catp;
	
	
	
	
	@BeforeMethod
	public void browserSetup() {
		catp = new CatagoryPage();
		catp.initialization();
	}
	@Test
	public void TC18_catagorypresent() {
		Assert.assertTrue(catp.TC18_Catagory());
		catp.click_on_Womenscatagory();
		catp.click_on_Dress();
		Assert.assertTrue(catp.Verify_Top_Products());
		catp.click_on_Men();
		catp.click_on_shirts();
	}

}
