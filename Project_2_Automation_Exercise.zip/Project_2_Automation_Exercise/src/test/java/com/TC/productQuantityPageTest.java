package com.TC;

import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.pages.ProductPage;
import com.pages.productQuantityPage;

public class productQuantityPageTest {
	
	
productQuantityPage pq;
	
	@BeforeMethod
	public void browserSetup() {
	pq = new productQuantityPage();
	pq.initialization();
	
	}
	@Test
	public void TC13_Click() {
		pq.TC9_Products();
		pq.TC13_ClickViewProduct();
		pq.increasequantity();
		pq.clickAddtocart();
		pq.viewcart();
		Assert.assertTrue(pq.VerifyQuantity());
	}
		
}

