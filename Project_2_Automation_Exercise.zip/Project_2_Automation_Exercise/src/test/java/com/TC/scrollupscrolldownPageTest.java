package com.TC;

import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.pages.LoginPage;
import com.pages.ProductPage;
import com.pages.SignupPage;
import com.pages.SubscriptionPage;
import com.pages.contactpage;
import com.pages.paymentPage;
import com.pages.scrollupscrolldownPage;

public class scrollupscrolldownPageTest {
scrollupscrolldownPage sc;
ProductPage prd;
SignupPage sp;
SubscriptionPage sub;
contactpage cpge;
LoginPage logp;
paymentPage page;
	
	@BeforeMethod
	public void browserSetup() {
	sc = new scrollupscrolldownPage();
	sc.initialization();

}
	@Test
	public void TC25_scrollupusingarrowbtn() {
		sc.TC26_ScrolldowntoBottom();
		sc.scrollup();
//		Assert.assertTrue(sc.subscriptionHome());//5. Verify 'SUBSCRIPTION' is visible
		sc.click_Scrollup_arrowbtn();
		Assert.assertTrue(sc.verify_fullWebsite());
	
	}
	
	@Test
	public void TC26_Scroll() {
		sc.TC26_ScrolldowntoBottom();
		sc.scrollup();
		Assert.assertTrue(sc.verify_fullWebsite());
		
	}
	@Test
	public void tc14_placeorder() {

	}

}