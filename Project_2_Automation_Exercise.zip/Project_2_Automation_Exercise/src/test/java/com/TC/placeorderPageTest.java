package com.TC;

import static org.testng.Assert.assertTrue;

import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.pages.CartPage;
import com.pages.LoginPage;
import com.pages.ProductPage;
import com.pages.SignupPage;
import com.pages.paymentPage;
import com.pages.placeorderPage;
import com.pages.productQuantityPage;

public class placeorderPageTest {
	
	   placeorderPage po;
	   ProductPage pg;	   
	   CartPage cp;
	   productQuantityPage pqp;
	   SignupPage sp;
	   paymentPage pay;
	   LoginPage lp;
	   
	   
		@BeforeMethod
		public void browserSetup() {			
		po = new placeorderPage();	
		pg = new ProductPage();
		pqp = new productQuantityPage();
		cp = new CartPage();
		sp = new SignupPage();
		pay = new paymentPage();
		lp = new LoginPage();
		pg.initialization();
		
			
		}
		
		@Test
		public void TC14_placeorder() {
		
			pg.TC12_HoverOnProductaddtocart();
			pqp.viewcart();
			po.ProceedtoCheckout();
			po.ClickonRegister_login();
			po.TC14_CAN();
			sp.fillsignupdetails();
			sp.filladdressinfo();
			sp.click_create_account();
			cp.TC11_Cart();
			po.alerthndl();
			po.ProceedtoCheckout();
			po.commentText();
			po.PlaceOrder();
			pay.TC14_enterpaymentdetails();
			pay.clickpayconfirmbtn();
			po.clickondeletebtn();
			po.clickcontinue();
			
		}
		@Test
		public void TC15_Registerbeforecheckout() {
			pg.TC12_HoverOnProductaddtocart();
			pqp.viewcart();
			po.ProceedtoCheckout();
			po.ClickonRegister_login();
			po.TC14_CAN();
			sp.fillsignupdetails();
			sp.filladdressinfo();
			sp.click_create_account();
			cp.TC11_Cart();
			po.alerthndl();
			po.ProceedtoCheckout();
			po.commentText();
			po.PlaceOrder();
			pay.TC14_enterpaymentdetails();
			pay.clickpayconfirmbtn();
			po.clickondeletebtn();
			po.clickcontinue();	
		}
		@Test
		public void TC16_LoginbfrCheckout() {
			lp.TC2_LoginDetails();
			Assert.assertTrue(po.TC16_VusernameinTop());
			pg.TC12_HoverOnProductaddtocart();
			pqp.viewcart();
			po.ProceedtoCheckout();
			po.ClickonRegister_login();
			po.TC14_CAN();
			sp.fillsignupdetails();
			sp.filladdressinfo();
			sp.click_create_account();
			cp.TC11_Cart();
			po.alerthndl();
			po.ProceedtoCheckout();
			po.commentText();
			po.PlaceOrder();
			pay.TC14_enterpaymentdetails();
			pay.clickpayconfirmbtn();
			po.clickondeletebtn();
			po.clickcontinue();
			
		}
}

