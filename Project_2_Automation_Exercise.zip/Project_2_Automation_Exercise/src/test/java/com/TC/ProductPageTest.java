package com.TC;

import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.pages.ProductPage;

public class ProductPageTest {
	ProductPage pp;
	
	@BeforeMethod
	public void browserSetup() {
	pp = new ProductPage();
	pp.initialization();	
		
	}
	@Test
	public void TC8_Products() {
		pp.TC9_Products();
		Assert.assertTrue(pp.VerifyNavigateToAllProducts());
		pp.TC8_ViewProduct();
		Assert.assertTrue(pp.VerifyProductCategoryisvisible());
		Assert.assertTrue(pp.VerifyPriceIsVisible());
		Assert.assertTrue(pp.VerifyAvailability());
		Assert.assertTrue(pp.VarifyCondition());
		Assert.assertTrue(pp.VerifyBrand());
		pp.EnterProductName();
		pp.ClickOnSearchButton();
		
	}
	@Test
	public void TC9_SearchProduct() {
		pp.TC9_Products();
		pp.prdctnameininput();
		pp.ClickOnSearchButton();
    	Assert.assertTrue(pp.VerifyNavigateToAllProducts());
		pp.searchprdctvisible();
	}
	
	@Test
	public void TC12_HoveronProd() {	
		pp.TC9_Products();
		pp.TC12_HoverOnProductaddtocart();
	
	    pp.ContinueShopping();

	    pp.TC12_Hover2nd();
	}

}
