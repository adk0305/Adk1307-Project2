package com.TC;

import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

//import com.pages.Homepage;
import com.pages.LoginPage;

public class LoginPageTest {

	LoginPage lp;
	
	@BeforeMethod
	public void browserSetup() {
		lp = new LoginPage();
		lp.initialization();
		
	}
		
	
	@Test
	public void LoginPage() {
//		hm.initialization();
		lp.TC2_LoginDetails();
//	    lp.TC2_LoginDetails();
	//	lp.verify_homePagePresent();
//		lp.TC3_invaliddetails();
	//	Assert.assertTrue(lp.verifyloggedinuser());
	//	Assert.assertTrue(lp.mailandpasswrdisincorrect());
	//	lp.TC4_Logout();
	//	lp.TC5_VerifyNewSignup();
	//	lp.VEmailalrdyexist();
	}
	
	public void Logout() {
		lp.TC4_Logout();
		
	}
}
	
