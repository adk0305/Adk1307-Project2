package com.TC;

import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.pages.contactpage;

public class contactpageTest {
	contactpage cp;
	
	  
	@BeforeMethod
	public void browserSetup() {
	cp = new contactpage();
	cp.initialization();
	}
	
	@Test
	public void contactus() {
		cp.TC6_clickoncontact();
		Assert.assertTrue(cp.verifygetintouch());
		cp.fillTheDtails();
        cp.UploadFile();
        cp.verifysuccess();
        cp.scrollingdown();
	}
	
		
	}


