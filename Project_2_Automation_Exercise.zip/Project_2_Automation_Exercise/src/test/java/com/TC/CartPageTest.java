package com.TC;

import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.pages.CartPage;

public class CartPageTest {
	CartPage cp;
	@BeforeMethod
	public void browserSetup() {
		cp = new CartPage();
		cp.initialization();
	}
	@Test
public void TC11_ClickOnCart() {
cp.TC11_Cart();
cp.VerifySubscriptionText();
cp.EnterEmail();
cp.VerifySuccessfullySbscribed();
}
}
